from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Product, NewProduct, Sale
from .serializers import ProductSerializer
from django.contrib.auth.models import User

class SalesProductView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        sales_products = Product.objects.filter(sales__isnull=False)
        serializer = ProductSerializer(sales_products, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class NewProductView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        new_products = Product.objects.filter(newproduct__is_active=True)
        serializer = ProductSerializer(new_products, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class RecommendedProductView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # Assuming we have a 'searches' model tracking user searches
        user = request.user
        recent_searches = user.searches.order_by('-timestamp')[:5]
        recommended_products = Product.objects.filter(id__in=[search.product_id for search in recent_searches])
        serializer = ProductSerializer(recommended_products, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ProductCategoryView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, cat_id):
        products_by_category = Product.objects.filter(category_id=cat_id)
        serializer = ProductSerializer(products_by_category, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

