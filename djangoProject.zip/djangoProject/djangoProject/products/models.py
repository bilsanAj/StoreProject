from django.db import models
from django.utils import timezone

class Brand(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)

class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name="products")
    brand = models.ForeignKey(Brand, on_delete=models.SET_NULL, null=True, related_name="products")
    color = models.CharField(max_length=50, blank=True, null=True)


class NewProduct(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="new_status")
    start_date = models.DateField(default=timezone.now)
    end_date = models.DateField(null=True, blank=True)

    @property
    def is_active(self):
        today = timezone.now().date()
        return self.start_date <= today and (self.end_date is None or today <= self.end_date)

class Sale(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="sales")
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2)
    start_date = models.DateField()
    end_date = models.DateField()
    @property
    def is_active(self):
        today = timezone.now().date()
        return self.start_date <= today and (self.end_date is None or today <= self.end_date)

class Search(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
