from django.urls import path
from . import views

app_name = 'products'

urlpatterns = [
    path('sales/', views.SalesProductView.as_view(), name='sales_products'),
    path('new/', views.NewProductView.as_view(), name='new_products'),
    path('recommendations/', views.RecommendedProductView.as_view(), name='recommended_products'),
    path('category/<int:cat_id>/', views.ProductCategoryView.as_view(), name='products_by_category'),
]
