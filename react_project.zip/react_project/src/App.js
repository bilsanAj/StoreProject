// App.js
import './App.css';
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Slider from './components/Slider';
import SubSidebar from './components/SubSidebar';
import SignUpForm from './components/SignUpForm';
import LoginModal from './components/LoginModal';
import Home from './components/Home';
import ProductDescription from './components/ProductDescription';
import ProductsList from './components/ProductsList';
import Footer from './components/Footer'
function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); 
  const [isSubSidebarOpen, setIsSubSidebarOpen] = useState(false);
  const [activeOption, setActiveOption] = useState('Dashboards');
  const sections = ['Living room', 'Kitchen', 'Bed room', 'Electronics'];

  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [open, setOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSignedUp, setIsSignedUp] = useState(false);
  //const [userName, setUserName] = useState('');
const userName = 'B. Abo Jawish';
  const handleOpen = () => setOpen(true);
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
    setIsSubSidebarOpen(false);
  };

  const SignUp = () => {
    setIsModalOpen(true);
    setIsLoginOpen(false);
  };

  const handleOptionClick = (option) => {
    const option1 = sidebarOptions.find((option1) => option1.label === option);
    const key = option1.key
    setActiveOption(option);
    setIsSubSidebarOpen(true);
    setSelectedOption(key);
    setAtivatedOption(option)
  };


  const toggleModal = () => {
    setIsLoginOpen(true);
  };
  const toggleCloseModal = (event) => {
    setIsModalOpen(false);
    setIsSignedUp(true);
    setIsLoginOpen(false);
    event.preventDefault();
  };
  
  const images = [
    'https://images.unsplash.com/photo-1639405069836-f82aa6dcb900?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://www.homelane.com/blog/wp-content/uploads/2024/04/shutterstock_1478159471.jpg',
    'https://images.unsplash.com/photo-1638886043487-72d203fa66b6?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://www.carpentry.sg/wp-content/uploads/2022/09/queens-road-8.jpg',
    'https://www.carpentry.sg/wp-content/uploads/2021/10/luxus-hill-drive-18-10-1.jpg',
  
  ];




  const [selectedOption, setSelectedOption] = useState(null);
  const [activatedOption, setAtivatedOption] = useState(null);
  const [isSubSidebarVisible, setIsSubSidebarVisible] = useState(false);




  const handleSubSidebarClose = () => {
    setIsSubSidebarVisible(false);
  };

  const handleMouseEnter = () => {
    setIsSubSidebarVisible(true);
  };

  const handleMouseLeave = () => {
    setIsSubSidebarVisible(false);
  };

  const [filters, setFilters] = useState({
    priceRange: [340, 2550], // Initial range values
  });

  // Handler to update filters
  const handleFilterChange = (filterName, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [filterName]: value,
    }));
  };

  return (
    <Router>
      <div className="App">
        <Navbar toggleSidebar={toggleSidebar} toggleModal={toggleModal} userName={userName} isSignedUp={isSignedUp}/>
        
        <div className="main-content">
          {isSidebarOpen && (
            <Sidebar
              options={sections}
              onOptionClick={handleOptionClick}
              isOpen={isSidebarOpen}
              closeSidebar={!isSidebarOpen}
            />
          )}
          {isSubSidebarOpen && (
            <div onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
              <SubSidebar
                activeOption={activatedOption}
                onClose={handleSubSidebarClose}
                closeSidebar ={toggleSidebar}
              />
            </div>
          )}

          <div className="content">
            <main className="main-content">
              <Routes>
                <Route path="/" element={<Home images={images}   />} />
                <Route path="/product/:productName" element={<ProductDescription />} />
                <Route path="/:productCat" element={<ProductsList filters={filters} handleFilterChange={handleFilterChange} />} />
              </Routes>
            </main>
          </div>
        </div>
        
        <LoginModal isLoginOpen={isLoginOpen} onClose={toggleCloseModal} SignUp={SignUp} />
        
        <SignUpForm isModalOpen={isModalOpen} onClose={toggleCloseModal} />
        <Footer/>
      </div>
    </Router>
  );
}

export default App;
