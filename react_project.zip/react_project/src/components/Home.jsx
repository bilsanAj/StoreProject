import React, { useState, useEffect } from 'react';
import CardProduct from './CardProduct';
//import '../StyleSheet/Home.css'
import Slider from './Slider'
import { useNavigate } from 'react-router-dom';
import ProductsList from './ProductsList';
import api from './api';
import { Box, Typography, Grid } from '@mui/material';

function Home({ images, topDeals, newItems, suggestions, userId }) {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();  const [products, setProducts] = useState([]);
  const [salesProducts, setSalesProducts] = useState([]);
  const [newProducts, setNewProducts] = useState([]);
  const [suggestedProducts, setSuggestedProducts] = useState([]);
  const handleCardClick = () => {
    // Navigate to the Product Page
    navigate('/product');
  };


  const fetchSuggestedProducts = async (categoryId) => {
    setLoading(true);
    try {
      const response = await api.get(`products/recommendations/${userId}/`);
      return(response.data);
      
    } catch (err) {
      console.error("Error fetching products:", err);
      setError("Failed to load products.");
    } finally {
      setLoading(false);
    }
  };
  const fetchNewProducts = async (categoryId) => {
    setLoading(true);
    try {
      const response = await api.get('products/new');
      return(response.data);
     
    } catch (err) {
      console.error("Error fetching products:", err);
      setError("Failed to load products.");
    } finally {
      setLoading(false);
    }
  };
  const fetchSalesProducts = async (categoryId) => {
    setLoading(true);
    try {
      const response = await api.get('products/sales');
      return(response.data);
      
    } catch (err) {
      console.error("Error fetching products:", err);
      setError("Failed to load products.");
    } finally {
      setLoading(false);
    }
  
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Call all the functions to fetch data
        const salesData = await fetchSalesProducts();
        const newData = await fetchNewProducts();
        const recommendedData = await fetchSuggestedProducts();
        
        // Set the state with the data received from the API calls
        setSalesProducts(salesData);
        setNewProducts(newData);
        setSuggestedProducts(recommendedData);

      } catch (err) {
        setError('Failed to fetch products.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData(); // Call the fetchData function when the component mounts
  });  // Re-run this effect if categoryId changes

  return (
    //Slider section
    <Box sx={{ width: '100%', padding: '40px', boxSizing: 'border-box' }}>
      <Box
        component="section"
        sx={{
          position: 'relative',
          width: '80%',
          height: '47vh',
          overflow: 'hidden',
          marginLeft: '150px'

        }}
      >

        <Slider images={images} autoSlideInterval={4000} />
      </Box>
      {/* Sales section */}

      <Box
        component="section"
        sx={{
          display: 'flex',
          flexDirection: 'column',
          marginTop: '200px',
          padding: 3,
          borderRadius: 2,

        }}


      >
        <div className="title-container">
          <h2 className="title">
            Top Deals
          </h2>
        </div>
        <Grid container   >
          {salesProducts.map((item, index) => (

            <Grid item xs={2} sm={2} md={2} key={index}>

              <CardProduct
                onClick={handleCardClick}
                product={item}
                image={item.img}
                title={item.name}
                price={item.price}
                discount={item.discount}
                isSale='true'
              />
            </Grid>
          ))}
        </Grid>


      </Box>
      {/* New collection section */}

      <Box
        component="section"
        sx={{
          display: 'flex',
          flexDirection: 'column',
          marginTop: '200px',
          padding: 3,
          borderRadius: 2,


        }}


      >
        <div className="title-container">
          <h2 className="title">
            New in     </h2>
        </div>
        <Grid container   >
          {newProducts.map((item, index) => (

            <Grid item xs={2} sm={2} md={2} key={index}>

              <CardProduct
                image={item.img}
                title={item.name}
                onClick={handleCardClick}
                product={item}
                price={item.price}
                isNew='true'
              />
            </Grid>
          ))}
        </Grid>


      </Box>



      {/* For You section */}


      <Box
        component="section"
        sx={{
          display: 'flex',
          flexDirection: 'column',
          marginTop: '200px',
          padding: 3,
          borderRadius: 2,


        }}


      >
        <div className="title-container">
          <h2 className="title">
            For you    </h2>
        </div>
        <Grid container   >
          {suggestedProducts.map((item, index) => (

            <Grid item xs={2} sm={2} md={2} key={index}>

              <CardProduct
                onClick={handleCardClick}
                product={item}
                image={item.img}
                title={item.name}
                price={item.price}


              />
            </Grid>
          ))}
        </Grid>


      </Box>

    </Box>

  );
}

export default Home;
