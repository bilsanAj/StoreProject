// ProductPage.js
import React from 'react';
import { Container, Box, Typography, Button, Divider, Grid, Rating, Accordion, AccordionSummary, AccordionDetails, requirePropFactory } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import '../StyleSheet/ProductDescription.css'; // Import external CSS
import { useNavigate, useLocation, useParams } from 'react-router-dom';



function ProductDescription() {
  const location = useLocation();
  const product = location.state?.product; 
  

  return (
    <Container sx={{marginLeft : '40px', width : '100%'}} display="flex" flexDirection="row" maxWidth="md">

<Typography variant="h4" gutterBottom>

       
      </Typography>
      {/* Image Carousel */}
      <Box sx={{width:'1500px'}}  display="flex" flexDirection="row">
      <Box sx={{width:'50%'}}  className="image-carousel" flex={1} padding={2}>
      
            
       <img src={require('../assets/Wash Machine6.jpg')} alt="product" className="product-image" />
            
        
        
      </Box>

      {/* Product Information */}
      <Box sx={{width:'50%'}} className="product-info" flex={1} padding={2}>
    
        <Typography variant="h5" fontWeight="bold">{product.name}</Typography>
        <Typography variant="h6" color="primary">€{product.price.toFixed(2)}</Typography>
        <Rating value={product.rating} readOnly />
        <Typography variant="body2">({product.reviews} reviews)</Typography>
        <Typography variant="subtitle1" mt={2}>{product.description}</Typography>

        {/* Availability Section */}
        <Box mt={3} className="availability">
          <Typography variant="body1"><strong>How to get it?</strong></Typography>
         
          <Divider />
          <Box mt={2}>
            <Typography variant="body2"><strong>Delivery:</strong> {product.delivery}</Typography>
            <Typography variant="body2"><strong>In-store:</strong> {product.availability}</Typography>
          </Box>
        </Box>
        <Typography variant="h4" gutterBottom>
    
      </Typography>
        {/* Add to Cart */}
        <Box mt={3} className="add-to-cart">
          <Box display="flex" alignItems="center" mb={1}>
            <Button variant="outlined">-</Button>
            <Typography variant="body1" mx={2}>1</Typography>
            <Button variant="outlined">+</Button>
          </Box>
          <Button variant="contained"  style={{backgroundColor : '#D8BFD8', width : '50%', marginTop : '30px'}} >
            Add to Cart
          </Button>
        </Box>
      </Box>

   </Box>

      {/* Similar Products */}
      <Box  flexDirection="row" className="similar-products">
        <Typography variant="h6" fontWeight="bold">Similar Products</Typography>
        <Grid container spacing={2} mt={2}>
          {/* {product.similarProducts.map((item, index) => ( */}

            {/* // <Grid item xs={6} sm={3} key={index}>
            //   <Box className="similar-product-card">
            //     <img src={item.image} alt={item.name} className="similar-product-image" />
            //     <Typography variant="body2">{item.name}</Typography>
            //     <Typography variant="body2" color="primary">€{item.price.toFixed(2)}</Typography>
            //   </Box>
            // </Grid>
          ))} */}
        </Grid>

        <img src={require('../assets/Wash Machine4.jpg')} className="similar-product-image" />
        <img src={require('../assets/Wash Machine2.jpg')}  className="similar-product-image" />
        <img src={require('../assets/Wash Machine1.jpg')}  className="similar-product-image" />

      </Box>

        {/* Accordion Section */}
        <Box mt={5}>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Product Information</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>Details about product dimensions, materials, and care instructions.</Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Dimensions</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>Product dimensions, weight, and other physical details.</Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Reviews</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>Reviews section where users can read and write reviews about the product.</Typography>
          </AccordionDetails>
        </Accordion>
      </Box>

    </Container>
  );
}

export default ProductDescription;
