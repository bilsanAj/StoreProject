import React from 'react';
import { Card, CardActions, CardContent, CardMedia, Button, Typography, IconButton } from '@mui/material';
import { Chip, Box, Stack } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import '../StyleSheet/CardProduct.css';
import { useNavigate } from 'react-router-dom';

const CardProduct = ({ image, title, isNew, price, discount, isSale, product }) => {
const navigate = useNavigate();

const handleCardClick = () => {
  navigate(`/product/${product.name}`, { state: { product } });

  };
  return (
    <Card sx={{ maxWidth: 205, boxShadow: 3, borderRadius: 2, height: 'auto' }} onClick={handleCardClick}>
      {/* Product Image */}
      <CardMedia
        component="img"
        height="200"
        image={image}
        alt={title}
        sx={{ objectFit: 'cover', textAlign: 'center' }}

      />

      {/* Card Content */}
      <CardContent sx={{ textAlign: 'center', }}>
        {/* Tags and QuickShip */}

        {isNew && (
          <Chip

            label="New"
            color="success"
            size="small"
            sx={{
              textAlign: 'center',
              fontWeight: 'bold',
              color: 'white',
            }}
          />
        )}
        {/* Title */}
        <Typography variant="h6" component="div" sx={{ fontWeight: 'bold', mb: 1 }}>
          {title}
        </Typography>

        {/* Price and Discount */}

        <Box display="flex" alignItems="center">

          {isSale ? (
            <>
              <Typography variant="h5" color="error" sx={{ fontWeight: 'bold' }}>
                {price}
              </Typography>
              {discount && (
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ textDecoration: 'line-through', marginLeft: 1 }}
                >
                  {discount}

                  <IconButton
                    color="black"
                    sx={{


                      left: 30, // Position the icon to the left with 16px margin
                      backgroundColor: 'white',
                      boxShadow: 2,
                      '&:hover': { backgroundColor: 'white' },
                    }}
                  >

                    <ShoppingCartIcon />
                  </IconButton>
                </Typography>
              )}
            </>
          ) : (
            <Typography style={{ width: "100%", alignItems: "center", marginLeft: '20px' }} align="center" variant="h5">
              {price}

              <IconButton
                color="black"
                sx={{


                  left: 35,
                  backgroundColor: 'white',
                  boxShadow: 2,
                  '&:hover': { backgroundColor: 'white' },
                }}
              >

                <ShoppingCartIcon />
              </IconButton>
            </Typography>




          )}






        </Box>

        {/* QuickShip */}





      </CardContent>
    </Card>
  );
};

export default CardProduct;
