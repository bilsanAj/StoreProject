import axios from 'axios';
import { React, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../StyleSheet/Sidebar.css';
import api from './api';
const SubSidebar = ({ activeOption, onClose, options, closeSidebar }) => {
  const [activeMenuItem, setActiveMenuItem] = useState(null);
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  const fetchProducts = async (categoryId) => {
    setLoading(true);
    try {
      const response = await api.get(`products/category/${categoryId}/`);
      setProducts(response.data);
      setError(null);
    } catch (err) {
      console.error("Error fetching products:", err);
      setError("Failed to load products.");
    } finally {
      setLoading(false);
    }
  };

  // Function to handle sub-option click
const handleSubOptionClick = (subOption) => {
    closeSidebar(false);
    fetchProducts(subOption);
    navigate('/washmachines', { state: { selectedSubOption: subOption, products: products } });
  };

  return (
    <div className="sub-sidebar">
      <h2>{activeOption}</h2>
      <ul className="sidebar-menu">
        {options.map((option, index) => (
          <li key={index} onClick={() => handleSubOptionClick(option)} className={`menu-item ${activeMenuItem === option ? 'active' : ''}`}
          >{option}</li>
        ))}
      </ul>
    </div>
  );
};

export default SubSidebar;

