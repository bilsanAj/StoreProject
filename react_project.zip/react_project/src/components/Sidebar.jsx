
import '../StyleSheet/Sidebar.css'; 
import React, { useState, useRef,useEffect } from 'react';


const Sidebar =({ options, onOptionClick, isOpen, closeSidebar }) => {
  // State to track the active menu item
  const [activeMenuItem, setActiveMenuItem] = useState('Dashboards'); // Default active item

  // Function to handle item click
  const handleMenuItemClick = (menuItem) => {
    
    setActiveMenuItem(menuItem); // Set the clicked item as active
  };

  const sidebarRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      // Check if the click is outside the sidebar
      if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        closeSidebar();  // Call your existing close function
      }
    };

    // Add the event listener only if the sidebar is open
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    // Remove the event listener when the sidebar closes or component unmounts
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, closeSidebar]); 





  return (
    <aside className={`sidebar ${isOpen ? 'open' : 'closed'}`}>

<ul className="sidebar-menu">
        {options.map((option) => (
          <li className={`menu-item ${activeMenuItem === option ? 'active' : ''}`}
          
          key={option} 
          onMouseMove={() => {
            onOptionClick(option);          
            handleMenuItemClick(option);   
          }}
          >
            {option}
           
          </li>
        ))}
      </ul>
      
    </aside>
  );
};

export default Sidebar;
