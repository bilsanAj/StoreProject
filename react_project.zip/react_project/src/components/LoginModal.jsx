// src/components/SignUpForm.jsx
import React, { useState } from 'react';
import { TextField, Button, Typography, Link, Box} from '@mui/material';
import CustomModal from './CustomModal';
import api from './api'; 
const LoginModal = ({ isLoginOpen, onClose, SignUp  }) => {


   // Import the axios instance

  // User Login function
const loginUser = async (email, password) => {
    try {
      const response = await api.post('account/login/', {
        email,
        password
      });
      
      // Store the token and user info in localStorage or state management
      const { token, user } = response.data;
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
  
      console.log('Login successful:', user);
      return response.data;  // Return user data and token
    } catch (error) {
      console.error('Error logging in user:', error.response ? error.response.data : error.message);
      throw error;
    }
  };
  
const handleLogin = ()=>{
  loginUser();
  onClose();

}

  const formContainerStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
    width: '100%',
  };
  if (!isLoginOpen) return null;
  return (
    <>
      {/* Trigger to open the modal */}
     
     
      {/* Reusable Modal */}
      <CustomModal open={isLoginOpen} onClose={onClose}  title="Log in">
        
      <Box
      component="form"
      sx={formContainerStyles}
      noValidate
      autoComplete="off"
    >

          <TextField
            label="E-mail"
            variant="standard"
            fullWidth
            margin="normal"
          />
          <TextField
            label="Password"
            variant="standard"
            type="password"
            fullWidth
            margin="normal"
          />
   
     <Button
        type="submit"
        variant="contained"
        fullWidth
        sx={{
          bgcolor: '#D8BFD8',
          color: '#fff',
          mt: 2,
          py: 1,
          fontSize: '16px',
        }}
        onClick={handleLogin} 
      >
      Login Now
      </Button>

      <Typography align="center" sx={{ mt: 2 }}>
        <Button onClick={SignUp} >
          Create account
        </Button>
    
      </Typography>

      {/* Social Media Links */}
      <Typography align="center" sx={{ mt: 2 }}>
        <Link href="#" sx={{ mx: 1 }}>Facebook</Link>
        •
        <Link href="#" sx={{ mx: 1 }}>Twitter</Link>
        •
        <Link href="#" sx={{ mx: 1 }}>LinkedIn</Link>
      </Typography>
        </Box>
      </CustomModal>
    </>
  );
};

export default LoginModal;
