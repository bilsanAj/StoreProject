import React, { useState } from 'react';
import { Slider,Box, Typography, Grid, List, ListItem, ListItemText, Checkbox, FormControl, InputLabel, Select, MenuItem, Pagination } from '@mui/material';
import CardProduct from './CardProduct';  // Import your existing Card component
import { useNavigate,useLocation } from 'react-router-dom';


const ProductsList = ({ filters, handleFilterChange }) => {
  // State for filters, sorting, and pagination
  const [brandFilters, setBrandFilters] = useState([]);
  const [colorFilters, setColorFilters] = useState([]);
  const [sort, setSort] = useState('');
  const [showCount, setShowCount] = useState(16);
  const [currentPage, setCurrentPage] = useState(1);
  const location = useLocation();
  
  const products = location.state?.products;
  // Dummy data for product list

  const handleSliderChange = (event, newValue) => {
    
    handleFilterChange('priceRange', newValue);
   
  };
  const navigate = useNavigate();
  const handleCardClick = () => {
    // Navigate to the Product Page
    navigate('/product');
  };
  // Handler functions
  const handleSortChange = (event) => setSort(event.target.value);
  const handleShowCountChange = (event) => setShowCount(event.target.value);
  const handlePageChange = (_, page) => setCurrentPage(page);

  return (
    <Box>
     
      {/* Main Content */}
      <Box display="flex" mt={2} px={2}>
        {/* Sidebar as a normal section */}
        <Box width="240px" p={2}  borderRadius={1} mr={3}>
          <Typography variant="h6" gutterBottom>Filters</Typography>

          {/* Brand Filter */}
          <Typography variant="subtitle1">Filter by Brand</Typography>
          <List>
            {['Everglades', 'Hisense', 'LG', 'Miele', 'AEG'].map((brand) => (
              <ListItem key={brand} button onClick={() => setBrandFilters([...brandFilters, brand])}>
                <Checkbox checked={brandFilters.includes(brand)} />
                <ListItemText primary={brand} />
              </ListItem>
            ))}
          </List>

          {/* Color Filter */}
          <Typography variant="subtitle1">Color</Typography>
          <List>
            {['Anthracite', 'Titanium Grey', 'Cast Iron Grey', 'RVS', 'Silver Inox'].map((color) => (
              <ListItem key={color} button onClick={() => setColorFilters([...colorFilters, color])}>
                <Checkbox checked={colorFilters.includes(color)} />
                <ListItemText primary={color} />
              </ListItem>
            ))}
          </List>
          <Box className="filter-section mt-4">
      <Typography variant="h6" gutterBottom>
        Prijs
      </Typography>
      
      <Slider
        value={filters.priceRange}
        onChange={handleSliderChange}
        valueLabelDisplay="auto"
        min={340}
        max={2550}
        sx={{ width: '100%' }} // Full width
      />
      
      <Typography variant="body2">
        €{filters.priceRange[0]} - €{filters.priceRange[1]}
      </Typography>
    </Box>
        </Box>

        {/* Product List and Sorting Area */}
        <Box flexGrow={1}>
          {/* Breadcrumb and Heading */}
          <Box mb={2}>
            <Typography variant="body2" color="textSecondary">
              Home {'>'} Washmachines
            </Typography>
            <Typography variant="h4" gutterBottom>Washmachines</Typography>
          </Box>

          {/* Sorting and Show Count Controls */}
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <FormControl variant="outlined" size="small">
              <InputLabel>Sort by</InputLabel>
              <Select value={sort} onChange={handleSortChange} label="Sort by">
                <MenuItem value="">Default Sorting</MenuItem>
                <MenuItem value="priceLowToHigh">Price: Low to High</MenuItem>
                <MenuItem value="priceHighToLow">Price: High to Low</MenuItem>
              </Select>
            </FormControl>

            <FormControl variant="outlined" size="small">
              <InputLabel>Show</InputLabel>
              <Select value={showCount} onChange={handleShowCountChange} label="Show">
                <MenuItem value={16}>16</MenuItem>
                <MenuItem value={32}>32</MenuItem>
                <MenuItem value={64}>64</MenuItem>
              </Select>
            </FormControl>
          </Box>

          {/* Product Grid */}
          <Grid container spacing={8}>
            {products.slice((currentPage - 1) * showCount, currentPage * showCount).map((item, index) => (
              <Grid item  xs={8} sm={16} md={2} key={index}>
                <CardProduct    onClick={handleCardClick}
            product={item}
            image={item.img}
            title={item.name}
            price={item.price}
             /> {/* Your Card component */}
              </Grid>
            ))}
          </Grid>

          {/* Pagination */}
          <Box display="flex" justifyContent="center" mt={3}>
            <Pagination
              count={Math.ceil(products.length / showCount)}
              page={currentPage}
              onChange={handlePageChange}
              color="primary"
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default ProductsList;
