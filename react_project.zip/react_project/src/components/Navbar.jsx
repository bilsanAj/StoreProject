import React from 'react';
import '../StyleSheet/Navbar.css'  // Assuming you create a CSS file for styles
import { FaBars } from 'react-icons/fa'; // Import FontAwesome icons
import {  Button,} from '@mui/material';

import { FaUserCircle } from 'react-icons/fa';

const Navbar = ({ toggleSidebar, toggleModal,isSignedUp, userName  }) => {
  return (
    <nav className="navbar">
      <div className="navbar-left">
      <FaBars className="toggle-sidebar-btn" onClick={toggleSidebar} />

     
        <img src={require("../assets/logo5.png")} alt="Logo" className="logo" />

      </div>
      <div className="navbar-center">
        <input type="text" className="search-bar" placeholder="Search..." />
      </div>
      <div className="navbar-right">
        <div className='lang'>
        <button className="lang-btn">EN</button>|
        <button className="lang-btn">NL</button>  
        </div>    
        <div className="profile-section">
        {!isSignedUp ? (
        <FaUserCircle size={40} color="#D8BFD8" onClick={toggleModal} /> 

) : (
  <p style={{fontSize:'22px'}} >
    {userName}
  </p>
)}

        </div>
      </div>
    </nav>
  );
};

export default Navbar;


