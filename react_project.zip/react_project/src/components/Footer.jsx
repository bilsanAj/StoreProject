import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

function Footer() {
  return (
    <Box
      component="footer"
      sx={{
        marginTop: '60px',
        backgroundColor: 'lightgray', // Light gray background
        padding: '32px 16px', // Increase padding (top-bottom: 32px, left-right: 16px)
        textAlign: 'center', // Center the text
        position: 'relative', // Allows for positioning if needed
        width: '100%', // Full width
        boxSizing: 'border-box', // Ensures padding is included in total width
        overflow: 'hidden', // Prevents overflow
      }}
    >
      <Typography variant="body1">
        © {new Date().getFullYear()} High Life. All rights reserved.
      </Typography>
    </Box>
  );
}

export default Footer;
