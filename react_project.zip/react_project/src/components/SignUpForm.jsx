// src/components/SignUpForm.jsx
import React, { useState } from 'react';
import { TextField, Button, Typography, Link, Box} from '@mui/material';
import CustomModal from './CustomModal';
import api from './api'; 

const SignUpForm = ({ isModalOpen, onClose }) => {
  // User Registration function
  const registerUser = async (email, password, firstName, lastName) => {
    try {
      const response = await api.post('account/register/', {
        email,
        password,
        first_name: firstName,
        last_name: lastName
      });
      
      // Store the token in localStorage or state management
      const { token, user } = response.data;
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
  
      console.log('Registration successful:', user);
      return response.data;  // Return user data and token
    } catch (error) {
      console.error('Error registering user:', error.response ? error.response.data : error.message);
      throw error;
    }
  };
  
const handleSignup =()=>{
  registerUser();
  onClose();
}


  const formContainerStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
    width: '100%',
  };
  if (!isModalOpen) return null;
  return (
    <>
      {/* Trigger to open the modal */}
     
     
      {/* Reusable Modal */}
      <CustomModal open={isModalOpen} onClose={!isModalOpen} title="Need an Account?">
        
      <Box
      component="form"
      sx={formContainerStyles}
      noValidate
      autoComplete="off"
    >
        <TextField
        label="Name"
        variant="standard"
        fullWidth
        required
        
      />
          <TextField
            label="E-mail"
            variant="standard"
            fullWidth
            margin="normal"
          />
          <TextField
            label="Password"
            variant="standard"
            type="password"
            fullWidth
            margin="normal"
          />
          <TextField
            label="Repeat Password"
            variant="standard"
            type="password"
            fullWidth
            margin="normal"
          />
     <Button
        type="submit"
        variant="contained"
        fullWidth
        sx={{
          bgcolor: '#D8BFD8',
          color: '#fff',
          mt: 2,
          py: 1,
          fontSize: '16px',
        }}
        onClick={handleSignup}
      >
        Sign Up Now
      </Button>

      <Typography align="center" sx={{ mt: 2 }}>
        <Link href="#" underline="none">
          I am already a member
        </Link>
      </Typography>

      {/* Social Media Links */}
      <Typography align="center" sx={{ mt: 2 }}>
        <Link href="#" sx={{ mx: 1 }}>Facebook</Link>
        •
        <Link href="#" sx={{ mx: 1 }}>Twitter</Link>
        •
        <Link href="#" sx={{ mx: 1 }}>LinkedIn</Link>
      </Typography>
        </Box>
      </CustomModal>
    </>
  );
};

export default SignUpForm;
