import axios from 'axios';

// Create an axios instance with baseURL
const api = axios.create({
  baseURL: 'http://localhost:8000/api/', // Replace with your backend URL
  headers: {
    'Content-Type': 'application/json',
  }
});

export default api;
