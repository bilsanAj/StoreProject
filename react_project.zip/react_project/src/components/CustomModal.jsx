// src/components/ReusableModal.jsx
import React from 'react';
import { Modal, Box, Typography, Button } from '@mui/material';
import cover from '../assets/family1.jpg'
const CustomModal = ({ open, onClose, title, children }) => {
  return (
    <Modal open={open} onClose={onClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          display: 'flex',
          width: '80vw',
          maxWidth: '900px',
          height: '80vh',
          backgroundColor: '#fff',
          boxShadow: 24,
          borderRadius: 8,
          overflow: 'hidden',
        }}
      >
        <Box
          sx={{
            flex: 1,
            backgroundImage:`url(${cover})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <Box
          sx={{
            flex: 1,
            padding: '40px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
          }}
        >
          <Typography variant="h4" gutterBottom>
            {title}
          </Typography>
          {children}
        </Box>
      </Box>
    </Modal>
  );
};

export default CustomModal;
