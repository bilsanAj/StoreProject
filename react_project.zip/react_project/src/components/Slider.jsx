// Slider.js
import React, { useState, useEffect } from 'react';
import { Box, Button } from '@mui/material';

const Slider = ({ images, interval = 3000 }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    // Set up an interval to automatically go to the next image
    const autoSlide = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, interval);

    // Clear interval on component unmount to prevent memory leaks
    return () => clearInterval(autoSlide);
  }, [images.length, interval]);



  return (
    <Box sx={{ position: 'relative',  height: '100%', width: '100%', overflow: 'hidden' }}>
      <Box
        component="img"
        src={images[currentIndex]}
        alt={`Slide ${currentIndex + 1}`}
        sx={{
          width: '100%',
          height: '100%',
          display: 'relative',
          transition: 'transform 0.5s ease-in-out',
        }}
      />


    </Box>
  );
};

export default Slider;
